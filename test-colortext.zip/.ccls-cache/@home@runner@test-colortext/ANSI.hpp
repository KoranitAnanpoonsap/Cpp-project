#ifndef ANSI_COLOR_CODE
#define ANSI_COLOR_CODE

void ANSI_Color();

#endif