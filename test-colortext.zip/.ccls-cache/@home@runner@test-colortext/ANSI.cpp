#include "ANSI.hpp"
#include <iostream>
using namespace std;

//ANSI escape code begins with \033[ or \e[, ends with m.  i.e. \033[31mTest = "Test" red text

// Color codes Text
// Reset 0, Black 30, Red 31, Green 32, Yellow 33, Blue 34, Magenta 35, Cyan 36,
// Bright Red 91, Bright Green 92, Bright Yellow 93, Bright Blue 94, Bright
// Magenta 95, Bright Cyan 96

// Color codes Background
// Black 40, Red 41, Green 42, Yellow 43, Blue 44, Magenta 45, Cyan 46, Bright
// Red 101, Bright Green 102, Bright Yellow 103, Bright Blue 104, Bright Magenta
// 105, Bright Cyan 106

//BOLDBLACK   "\033[1m\033[30m"
//BOLDWhite  "\033[1m\033[0m"

void ANSI_Color() {
  cout << "\e[30m" << "This text is black" << endl;
  cout << "\e[31m" << "This text is red" << endl;
  cout << "\e[32m" << "This text is green" << endl;
  cout << "\033[33mThis text is yellow" << endl;
  cout << "\033[34mThis text is blue" << endl;
  cout << "\033[35mThis text is magenta" << endl;
  cout << "\033[36mThis text is cyan\n" << endl;
	
  cout << "\033[91mThis text is Bright Red" << endl;
  cout << "\033[92mThis text is Bright Green" << endl;
  cout << "\033[93mThis text is Bright Yellow" << endl;
  cout << "\033[94mThis text is Bright Blue" << endl;
  cout << "\033[95mThis text is Bright Magenta" << endl;
  cout << "\033[96mThis text is Bright Cyan\n" << "\033[0m" << endl;
 
	cout << "\e[40m" << "     Black bg    " << endl;
	cout << "\e[41m" << "      Red bg     " << endl;
	cout << "\e[42m" << "     Green bg    " << endl;
	cout << "\e[43m" << "     Yellow bg   " << endl;
	cout << "\e[44m" << "     Blue bg     " << endl;
	cout << "\e[45m" << "    Magenta bg   " << endl;
	cout << "\e[46m\e[1m" << "     Cyan bg     " << endl;  // Cyan bg + black text
	
  cout << "\e[0m" << "\n||-------------\e[31mTest\e[0m----------------||\n\n"; //  \033[0m = reset color
	
	cout << "Normal text" << endl;
	cout << "\e[1m" << "Bold text" << endl;
	cout << "\e[2m" << "Fade Text" << "\e[0m" << endl;
	cout << "\e[3m" << "Italic Text" << "\e[0m" << endl;
	cout << "\e[4m" << "Underline Text" << "\e[0m" << endl;
	
}