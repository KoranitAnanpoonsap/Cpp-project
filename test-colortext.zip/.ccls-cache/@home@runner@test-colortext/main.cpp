#include <iostream>
#include "ANSI.hpp"

using namespace std;

int main(){
	cout << "Hello world" << endl;
	ANSI_Color();
}